import {Component, OnInit} from '@angular/core';
//import {FormsModule} from '@angular/forms'// this will be usefull when we implement template driven approach for forms in angular2
import {FormGroup,FormArray, FormBuilder, Validators, AbstractControl, ValidatorFn} from '@angular/forms';
import 'rxjs/add/operator/debounceTime';
import {Employee} from './employee';

//Below code is related to cross field validator and their usages.

function emailMatcher(c: AbstractControl)// this parameter is passed to method to get both email and confirmEmail controls.
{
            let emailControl= c.get('email');// this will get email form control.
        let confirmControl = c.get('confirmEmail');// this will get confirmEmail form control.

         if(emailControl.pristine || confirmControl.pristine)
         {
             return null;
         }
       
        if(emailControl.value === confirmControl.value)
        {
            return null;
        }
        return{ 'match': true}; 
}


//Below is example of custom validation with parameter.
function ratingRange(min: number, max: number): ValidatorFn{
return  (c: AbstractControl):{[key: string]: boolean} | null =>{
     if(c.value != undefined && (isNaN(c.value) || c.value<min || c.value>max))
     {
         return {'range' : true};
     }
    return null;
}
}

//Below is the example for cross-field validation: this is also caled as nested FormGroup validation
//(Example end date should not be less then start date)

//Below is the example of custom validation.
// function ratingRange(c: AbstractControl):{[key: string]: boolean} | null{
//      if(c.value != undefined && (isNaN(c.value) || c.value<1 || c.value>5))
//      {
//          return {'range' : true};
//      }
//     return null;
// }

@Component({
    selector:'my-signup',
    templateUrl:'./app/Employee/employee-detail.component.html'
})
export class EmployeeComponent implements OnInit{
    customerForm: FormGroup;
    customer: Employee = new Employee();
    emailMessage: string;
   
    get addresses(): FormArray{
        return <FormArray> this.customerForm.get('addresses');
    }

    private validationMessage ={
        required: 'please enter your email address.',
        pattern: 'please enter a valid email address'
    }

    constructor(private fb: FormBuilder){}
    ngOnInit(): void {
        // below is the approach to write validations in conponenet in reactive forms
       this.customerForm = this.fb.group({
           firstName: ['',[Validators.required, Validators.minLength(3)]],
           lastName: ['', [Validators.required, Validators.maxLength(5)]],
           emailGroup: this.fb.group({
                       email: ['',[Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+')]],
                       confirmEmail: ['', Validators.required],
           },{validator: emailMatcher}), 
           phone: '',
           notification: 'email',
           rating: ['', ratingRange(1,5)],
           sendCatalog: true,
           addresses : this.fb.array([this.buildAddresses()])
           
           //commenting this part,as this will be part of form group to duplicate the properties of addess
        //    addressType: 'home',
        //    street1: '',
        //    street2:'',
        //    city:'',
        //    state:'',
        //    zip:''

       })

       // this code is create watcher on the event, as soon as user clicks on radio button their will be one
       // event triggered according to that user can take action on that.
       this.customerForm.get('notification')
           .valueChanges.subscribe(value=> this.setNotification(value));

           //alternative of above code you can call below line of code in html where it will trigger according to the event.
           //(click) = "setNotification('text')"-->

            const emailControl = this.customerForm.get('emailGroup.email');
            emailControl.valueChanges.debounceTime(3000).subscribe(value => this.setMessage(emailControl));

        // this is first way of diclaring formcontrols in reactive forms.
        // this.customerForm = this.fb.group({
        //     firstName :'',
        //     lastName:'',
        //     email:'',
        //     sendCatelog:true
        // })
     // this way fo diclaring form controlls will work with both parameters value and disabled.

    //    this.customerForm = this.fb.group({
    //        firstName: {value: 'jack', disabled:true },
    //        lastName: {value: 'jones', disabled: false},
    //        email: {value: 'jack@gmail.com', disabled: false},
    //        sendCatelog: true
    //    })
    

// this is the third way of diclaring form controls, where we use array to diclare it.
//  this.customerForm = this.fb.group({
//          firstName: [''],
//          sendCatelog: [{value: false, disabled: true}]
//       })

    //For this you need to import FormGroup from forms.
    //   this.customerForm = new FormGroup({
    //       firstName: new FormControl(),
    //       lastName:  new FormControl(),
    //       email : new FormControl(),
    //       sendCatelog : new FormControl(true)
    //   });
    }
    save()
    {
        console.log(this.customerForm);
        console.log('Saved' + JSON.stringify(this.customerForm.value));
    }

setMessage(c:AbstractControl):void{
    this.emailMessage= '';
    if((c.touched || c.dirty) && c.errors)
    {
        this.emailMessage = Object.keys(c.errors).map(key => this.validationMessage[key]).join('');
    }
}

    populateTestData(): void
    {
        this.customerForm.setValue({
            firstName : 'jack',
            lastName : 'jones',
            email: 'jack@gmail.com',
            phone: '8050480140',
            notification: 'email',
            sendCatalog : false

        })
    }

//    partialTestData(): void
//     {
//         this.customerForm.patchValue({
//             firstName : 'john',
//             lastName : 'sina',
//             sendCatelog : true
//         })
//     }
//     resetTestData(): void
//     {
//         this.customerForm.setValue({
//             firstName : '',
//             lastName : '',
//             email: '',
//             sendCatelog : true

//         })
//     }

    setNotification(notifyVia: string): void{
        const phoneControl  = this.customerForm.get('phone');
        if(notifyVia === 'text')
        {
            phoneControl.setValidators(Validators.required);
        }
        else{
            phoneControl.clearValidators();
        }
        phoneControl.updateValueAndValidity();// this code is required to reevaluate phone control validation again.

    }

    addAddresses(): void{
        this.addresses.push(this.buildAddresses());
    }
    buildAddresses(): FormGroup{
        return this.fb.group({
           addressType: 'home',
           street1: '',
           street2:'',
           city:'',
           state:'',
           zip:''
    });
 }
    
}