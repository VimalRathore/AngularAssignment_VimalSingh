"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ProjectData = (function () {
    function ProjectData() {
    }
    ProjectData.prototype.createDb = function () {
        var projects = [
            {
                'id': 1,
                'projectName': 'Leaf Rake',
                'projectCode': 'GDN-0011',
                'startedDate': 'March 19, 2016',
                'description': 'Leaf rake with 48-inch wooden handle.',
                'costOfProject': 19.95,
                'workRating': 3.2,
                "projectLocation": 'USA',
                "strengthOfProject": 1000,
                'imageUrl': 'https://content-static.upwork.com/blog/uploads/sites/4/2009/05/project-management.jpg',
            },
            {
                'id': 2,
                'projectName': 'Garden Cart',
                'projectCode': 'GDN-0023',
                'startedDate': 'March 18, 2016',
                'description': '15 gallon capacity rolling garden cart',
                'costOfProject': 32.99,
                'workRating': 4.2,
                "projectLocation": 'USA',
                "strengthOfProject": 1000,
                'imageUrl': 'http://edison-project.eu/sites/edison-project.eu/files/images/edison-project-logo.png',
            },
            {
                'id': 3,
                'projectName': 'Hammer',
                'projectCode': 'TBX-0048',
                'startedDate': 'May 21, 2016',
                'description': 'Curved claw steel hammer',
                'costOfProject': 8.9,
                'workRating': 4.8,
                "projectLocation": 'USA',
                "strengthOfProject": 1000,
                'imageUrl': 'https://www.pcsb.org/cms/lib/FL01903687/centricity/domain/204/Logo_get_engaged_Color_sm.jpg',
            },
            {
                'id': 4,
                'projectName': 'Saw',
                'projectCode': 'TBX-0022',
                'startedDate': 'May 15, 2016',
                'description': '15-inch steel blade hand saw',
                'costOfProject': 11.55,
                'workRating': 3.7,
                "projectLocation": 'USA',
                "strengthOfProject": 1000,
                'imageUrl': 'http://insideedison.com/media/themes/55f346a05e8eef5d04d8caea/fonts/ie-logo.svg',
            },
            {
                'id': 5,
                'projectName': 'Video Game Controller',
                'projectCode': 'GMG-0042',
                'startedDate': 'October 15, 2015',
                'description': 'Standard two-button video game controller',
                'costOfProject': 35.95,
                "projectLocation": 'USA',
                'workRating': 4.6,
                "strengthOfProject": 1000,
                'imageUrl': 'http://www.bestvalueschools.com/wp-content/uploads/2014/06/Thomas-Edison-State-College-Online-Bachelor-of-Science-in-Business-Administration-Degree.png',
            }
        ];
        return { projects: projects };
    };
    return ProjectData;
}());
exports.ProjectData = ProjectData;
//# sourceMappingURL=project-data.js.map