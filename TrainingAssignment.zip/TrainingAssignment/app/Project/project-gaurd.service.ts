import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, CanDeactivate } from '@angular/router';

import { ProjectEditComponent } from './project-edit.component';

 @Injectable()

 export class ProjectDetailGuard implements CanActivate{
     constructor(private _router: Router){}
     canActivate(router: ActivatedRouteSnapshot): boolean{
         let id = +router.url[1].path
        if(isNaN(id) || id<1)
         {
             alert('Wrong url!!');
             this._router.navigate(['/projects']);
             return false;
         }
         return true;
     }
 }


@Injectable()
export  class ProjectEditGuard implements CanDeactivate<ProjectEditComponent> {

    canDeactivate(component: ProjectEditComponent): boolean {
        if (component.projectForm.dirty) {
            let projectName = component.projectForm.get('projectName').value || 'New Proje';
            return confirm(`Navigate away and lose all changes to ${projectName}?`);
        }
        return true;
    }
}


