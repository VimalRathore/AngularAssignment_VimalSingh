"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
require("rxjs/add/operator/debounceTime");
require("rxjs/add/observable/fromEvent");
require("rxjs/add/observable/merge");
var Observable_1 = require("rxjs/Observable");
//import { ProjectDetailGuard } from './project-gaurd.service';
var project_list_service_1 = require("./project-list.service");
var number_validator_1 = require("../shared/number.validator");
var generic_validator_1 = require("../shared/generic-validator");
var ProjectEditComponent = (function () {
    function ProjectEditComponent(fb, route, router, projectService) {
        this.fb = fb;
        this.route = route;
        this.router = router;
        this.projectService = projectService;
        this.pageTitle = 'Project Edit';
        // Use with the generic validation message class
        this.displayMessage = {};
        // Defines all of the validation messages for the form.
        // These could instead be retrieved from a file or database.
        this.validationMessages = {
            projectName: {
                required: 'Project name is required.',
                minlength: 'Project name must be at least three characters.',
                maxlength: 'Project name cannot exceed 50 characters.'
            },
            projectCode: {
                required: 'Project code is required.'
            },
            workRating: {
                range: 'Rate the Project between 1 (lowest) and 5 (highest).'
            }
        };
        // Define an instance of the validator for use with this form, 
        // passing in this form's set of validation messages.
        this.genericValidator = new generic_validator_1.GenericValidator(this.validationMessages);
    }
    Object.defineProperty(ProjectEditComponent.prototype, "tags", {
        get: function () {
            return this.projectForm.get('tags');
        },
        enumerable: true,
        configurable: true
    });
    ProjectEditComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.projectForm = this.fb.group({
            projectName: ['', [forms_1.Validators.required,
                    forms_1.Validators.minLength(3),
                    forms_1.Validators.maxLength(50)]],
            projectCode: ['', forms_1.Validators.required],
            workRating: ['', number_validator_1.NumberValidators.range(1, 5)],
            tags: this.fb.array([]),
            description: ''
        });
        // Read the project Id from the route parameter
        this.sub = this.route.params.subscribe(function (params) {
            var id = +params['id'];
            _this.getproject(id);
        });
    };
    // This code will ensure that subscription is cleaned up, this code is using ngOnDestroy lifecylce hook.
    ProjectEditComponent.prototype.ngOnDestroy = function () {
        this.sub.unsubscribe();
    };
    ProjectEditComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        // Watch for the blur event from any input element on the form.
        var controlBlurs = this.formInputElements
            .map(function (formControl) { return Observable_1.Observable.fromEvent(formControl.nativeElement, 'blur'); });
        // Merge the blur event observable with the valueChanges observable
        Observable_1.Observable.merge.apply(Observable_1.Observable, [this.projectForm.valueChanges].concat(controlBlurs)).debounceTime(8).subscribe(function (value) {
            _this.displayMessage = _this.genericValidator.processMessages(_this.projectForm);
        });
    };
    ProjectEditComponent.prototype.addTag = function () {
        this.tags.push(new forms_1.FormControl());
    };
    ProjectEditComponent.prototype.getproject = function (id) {
        var _this = this;
        this.projectService.getProject(id)
            .subscribe(function (project) { return _this.onprojectRetrieved(project); }, function (error) { return _this.errorMessage = error; });
    };
    ProjectEditComponent.prototype.onprojectRetrieved = function (project) {
        if (this.projectForm) {
            this.projectForm.reset();
        }
        this.project = project;
        if (this.project.id === 0) {
            this.pageTitle = 'Add project';
        }
        else {
            this.pageTitle = "Edit project: " + this.project.projectName;
        }
        // Update the data on the form
        this.projectForm.patchValue({
            projectName: this.project.projectName,
            projectCode: this.project.projectCode,
            workRating: this.project.workRating,
            description: this.project.description
        });
        this.projectForm.setControl('tags', this.fb.array(this.project.tags || []));
    };
    ProjectEditComponent.prototype.deleteproject = function () {
        var _this = this;
        alert('Hi');
        if (this.project.id === 0) {
            // Don't delete, it was never saved.
            this.onSaveComplete();
        }
        else {
            if (confirm("Really delete the project: " + this.project.projectName + "?")) {
                this.projectService.deleteProject(this.project.id)
                    .subscribe(function () { return _this.onSaveComplete(); }, function (error) { return _this.errorMessage = error; });
            }
        }
    };
    ProjectEditComponent.prototype.saveProject = function () {
        var _this = this;
        //alert("saveProject");
        if (this.projectForm.dirty && this.projectForm.valid) {
            // Copy the form values over the project object values
            var p = Object.assign({}, this.project, this.projectForm.value);
            this.projectService.saveProject(p)
                .subscribe(function () { return _this.onSaveComplete(); }, function (error) { return _this.errorMessage = error; });
        }
        else if (!this.projectForm.dirty) {
            //alert('Calling onSaveComplete');
            this.onSaveComplete();
        }
    };
    ProjectEditComponent.prototype.onSaveComplete = function () {
        //alert('onSaveComplete');
        // Reset the form to clear the flags
        this.projectForm.reset();
        this.router.navigate(['/projects']);
    };
    __decorate([
        core_1.ViewChildren(forms_1.FormControlName, { read: core_1.ElementRef }),
        __metadata("design:type", Array)
    ], ProjectEditComponent.prototype, "formInputElements", void 0);
    ProjectEditComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            templateUrl: 'project.edit.component.html'
        }),
        __metadata("design:paramtypes", [forms_1.FormBuilder,
            router_1.ActivatedRoute,
            router_1.Router,
            project_list_service_1.ProjectListService])
    ], ProjectEditComponent);
    return ProjectEditComponent;
}());
exports.ProjectEditComponent = ProjectEditComponent;
//# sourceMappingURL=project-edit.component.js.map