import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';

import { IProjectProperties } from './projectProperties';

@Injectable()
export class ProjectListService {
    //private baseUrl =  "http://localhost:62055/api/project"
    private baseUrl = 'api/projects'
 
    constructor(private http: Http) { }

    getProjects(): Observable<IProjectProperties[]> {
       
        return this.http.get(this.baseUrl)
            .map(this.extractData)
            //.map(res => res.json())
            .do(data => console.log('getProjects: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    //this.http.get(url).map(res => res.json());

    getProject(id: number): Observable<IProjectProperties> {
        
        if (id === 0) {
        return Observable.of(this.initializeProject());
        // return Observable.create((observer: any) => {
        //     observer.next(this.initializeproject());
        //     observer.complete();
        // });
        };
        const url = `${this.baseUrl}/${id}`;
        return this.http.get(url)
            .map(this.extractData)
            .do(data => console.log('getProject: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    deleteProject(id: number): Observable<Response> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });

        const url = `${this.baseUrl}/${id}`;
        return this.http.delete(url, options)
            .do(data => console.log('deleteProject: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    saveProject(project: IProjectProperties): Observable<IProjectProperties> {
        //alert("Service Save");
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        //project.id = 11;
        //alert(project.id);
        if (project.id === 0) {
            return this.createProject(project, options);
        }
        return this.updateProject(project, options);
    }

    private createProject(project: IProjectProperties, options: RequestOptions): Observable<IProjectProperties> {
        project.id = undefined;
        return this.http.post(this.baseUrl, project, options)
            .map(this.extractData)
            .do(data => console.log('createproject: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    private updateProject(project: IProjectProperties, options: RequestOptions): Observable<IProjectProperties> {
         //alert("updateProject");
        const url = `${this.baseUrl}/${project.id}`;
        return this.http.put(url, project, options)
            .map(() => project)
            .do(data => console.log('updateproject: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    private extractData(response: Response) {
        let body = response.json();
        return body.data || {};
    }

    private handleError(error: Response): Observable<any> {
        // in a real world app, we may send the server to some remote logging infrastructure
        // instead of just logging it to the console
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

    initializeProject(): IProjectProperties {
        // Return an initialized object
        return {
            id: 0,
            projectName: null,
            projectCode: null,
            tags: [''],
            startedDate: null,
            description: null,
            projectLocation: null,
            strengthOfProject: null,
            costOfProject: null,
            workRating: null,
            imageUrl: null
        };
    }
}
