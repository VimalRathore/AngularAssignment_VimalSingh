import {Component, OnInit, OnChanges} from '@angular/core'
import {FormsModule} from '@angular/forms'

import {IProjectProperties} from './projectProperties';
import {ProjectListService} from './project-list.service'

@Component({
selector: 'pm-projects',
moduleId: module.id,
templateUrl: 'project-list.component.html',
styleUrls: ['project-list.component.css']

})
export class ProjectListComponent implements OnInit, OnChanges{
    pageTitle: string ="Project List";
    showImage: boolean = true;
    imageWidth: number = 51;
    imageMargin: number = 4;
    listFilter : string = '';
    errorMessage: string// = 'Error has been occured while calling this service!!';
    projects: IProjectProperties[];
    

    constructor(private _projectService : ProjectListService){

    }

    toggleImage(): boolean{
       return this.showImage = ! this.showImage;
    }

     ngOnInit(){
         this._projectService.getProjects()
                    .subscribe(projects => this.projects = projects,
                    error => this.errorMessage = <any> error)
        console.log('Hey, buddy you have implemented OnInit life cycle hook!!!');
     }

// this hook will come in picture when we will have input parameter to other component or nested component implementation. 
     ngOnChanges(){
         console.log('Hey, buddy you have implemented OnChanges life cycle hook!!!');
     }

      onRatingClicked(message: string): void{
    this.pageTitle = 'Project List' + message;
}

}