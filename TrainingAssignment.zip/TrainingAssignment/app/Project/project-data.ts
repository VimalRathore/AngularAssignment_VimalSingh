import { InMemoryDbService } from 'angular-in-memory-web-api';

import { IProjectProperties } from './projectProperties';

export class ProjectData implements InMemoryDbService {

    createDb() {
        let projects: IProjectProperties[] = [
            {
                'id': 1,
                'projectName': 'Leaf Rake',
                'projectCode': 'GDN-0011',
                'startedDate': 'March 19, 2016',
                'description': 'Leaf rake with 48-inch wooden handle.',
                'costOfProject': 19.95,
                'workRating': 3.2,
                "projectLocation": 'USA',
                "strengthOfProject": 1000,
                'imageUrl': 'https://content-static.upwork.com/blog/uploads/sites/4/2009/05/project-management.jpg',
                //'tags': ['rake', 'leaf', 'yard', 'home']
            },
            {
                'id': 2,
                'projectName': 'Garden Cart',
                'projectCode': 'GDN-0023',
                'startedDate': 'March 18, 2016',
                'description': '15 gallon capacity rolling garden cart',
                'costOfProject': 32.99,
                'workRating': 4.2,
                 "projectLocation": 'USA',
                "strengthOfProject": 1000,
                'imageUrl': 'http://edison-project.eu/sites/edison-project.eu/files/images/edison-project-logo.png',
                //'tags': ['rake', 'leaf', 'yard', 'home']
            },
            {
                'id': 3,
                'projectName': 'Hammer',
                'projectCode': 'TBX-0048',
                'startedDate': 'May 21, 2016',
                'description': 'Curved claw steel hammer',
                'costOfProject': 8.9,
                'workRating': 4.8,
                 "projectLocation": 'USA',
                 "strengthOfProject": 1000,
                'imageUrl': 'https://www.pcsb.org/cms/lib/FL01903687/centricity/domain/204/Logo_get_engaged_Color_sm.jpg',
                //'tags': ['tools', 'hammer', 'construction']
            },
            {
                'id': 4,
                'projectName': 'Saw',
                'projectCode': 'TBX-0022',
                'startedDate': 'May 15, 2016',
                'description': '15-inch steel blade hand saw',
                'costOfProject': 11.55,
                'workRating': 3.7,
                 "projectLocation": 'USA',
                 "strengthOfProject": 1000,
                'imageUrl': 'http://insideedison.com/media/themes/55f346a05e8eef5d04d8caea/fonts/ie-logo.svg',
                //'tags': ['rake', 'leaf', 'yard', 'home']
            },
            {
                'id': 5,
                'projectName': 'Video Game Controller',
                'projectCode': 'GMG-0042',
                'startedDate': 'October 15, 2015',
                'description': 'Standard two-button video game controller',
                'costOfProject': 35.95,
                 "projectLocation": 'USA',
                'workRating': 4.6,
                 "strengthOfProject": 1000,
                'imageUrl': 'http://www.bestvalueschools.com/wp-content/uploads/2014/06/Thomas-Edison-State-College-Online-Bachelor-of-Science-in-Business-Administration-Degree.png',
                //'tags': ['rake', 'leaf', 'yard', 'home']
            }
        ];
        return { projects };
    }
}
