"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var http_1 = require("@angular/http");
var router_1 = require("@angular/router");
var angular_in_memory_web_api_1 = require("angular-in-memory-web-api");
var project_data_1 = require("./project-data");
var project_list_component_1 = require("../Project/project-list.component");
var project_pipe_1 = require("../Project/project-pipe");
var project_detail_component_1 = require("../Project/project-detail.component");
var project_gaurd_service_1 = require("../Project/project-gaurd.service");
var Project_list_service_1 = require("./Project-list.service");
var shared_module_1 = require("../shared/shared.module");
var project_edit_component_1 = require("../Project/project-edit.component");
var ProjectModel = (function () {
    function ProjectModel() {
    }
    ProjectModel = __decorate([
        core_1.NgModule({
            declarations: [
                project_list_component_1.ProjectListComponent,
                project_detail_component_1.ProjectDetailComponent,
                project_pipe_1.ProjectFilterPipe,
                project_edit_component_1.ProjectEditComponent
            ],
            imports: [
                http_1.HttpModule,
                forms_1.ReactiveFormsModule,
                angular_in_memory_web_api_1.InMemoryWebApiModule.forRoot(project_data_1.ProjectData),
                router_1.RouterModule.forChild([
                    { path: 'projects', component: project_list_component_1.ProjectListComponent },
                    { path: 'project/:id', canActivate: [project_gaurd_service_1.ProjectDetailGuard], component: project_detail_component_1.ProjectDetailComponent },
                    { path: 'projectEdit/:id', canDeactivate: [project_gaurd_service_1.ProjectEditGuard], component: project_edit_component_1.ProjectEditComponent },
                ]),
                shared_module_1.SharedModule,
            ],
            providers: [Project_list_service_1.ProjectListService, project_gaurd_service_1.ProjectDetailGuard, project_gaurd_service_1.ProjectEditGuard],
        })
    ], ProjectModel);
    return ProjectModel;
}());
exports.ProjectModel = ProjectModel;
//# sourceMappingURL=project.module.js.map