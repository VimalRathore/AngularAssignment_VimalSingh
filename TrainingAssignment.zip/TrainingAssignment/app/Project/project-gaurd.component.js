"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
core_1.Injectable();
var ProjectGaurd = (function () {
    function ProjectGaurd(_router) {
        this._router = _router;
    }
    ProjectGaurd.prototype.canActivate = function (router) {
        var id = +router.url[1].path;
        if (isNaN(id) || id < 1) {
            alert('Wrong url!!');
            this._router.navigate(['/products']);
            return false;
        }
        return true;
    };
    return ProjectGaurd;
}());
exports.ProjectGaurd = ProjectGaurd;
//# sourceMappingURL=project-gaurd.component.js.map