export interface IProjectProperties{
    id: number
    projectName: string
    projectCode: string
    tags?: string[];
    startedDate: string
    description: string
    projectLocation: string
    strengthOfProject : number
    costOfProject: number
    workRating: number 
    imageUrl: string   
}