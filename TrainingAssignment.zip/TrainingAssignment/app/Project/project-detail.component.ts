import {Component, OnInit} from '@angular/core'
import {IProjectProperties} from './projectProperties'
import {ActivatedRoute,Router} from '@angular/router';

@Component({
    selector:'',
    moduleId: module.id,
    templateUrl:'project-detail.component.html'
})


export class ProjectDetailComponent implements OnInit{
pageTitle: string = 'Project Details';
project: IProjectProperties;

constructor(private _route: ActivatedRoute, private router:Router){
    }

    onBack():void{
    this.router.navigate(['./projects'])
}

ngOnInit():void{
    let id =+ this._route.snapshot.params['id'];
    this.pageTitle += `:${id}`;
}
}