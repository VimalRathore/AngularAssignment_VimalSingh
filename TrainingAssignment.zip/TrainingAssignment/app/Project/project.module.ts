import {NgModule} from '@angular/core';
import {ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {RouterModule} from '@angular/router'
import{InMemoryWebApiModule} from 'angular-in-memory-web-api';
import {ProjectData} from './project-data';

import {ProjectListComponent} from '../Project/project-list.component';
import {ProjectFilterPipe} from '../Project/project-pipe';
import {ProjectDetailComponent} from '../Project/project-detail.component'
import {ProjectDetailGuard, ProjectEditGuard} from '../Project/project-gaurd.service';
import {ProjectListService} from './Project-list.service';
import {SharedModule} from '../shared/shared.module'
import {ProjectEditComponent} from '../Project/project-edit.component'; 

@NgModule({
declarations:[
    ProjectListComponent,
    ProjectDetailComponent,
    ProjectFilterPipe,
    ProjectEditComponent
],
imports:[
    HttpModule,
    ReactiveFormsModule,
    InMemoryWebApiModule.forRoot(ProjectData),
    RouterModule.forChild([
    {path:'projects',  component:ProjectListComponent},
    {path: 'project/:id', canActivate:[ProjectDetailGuard] ,component: ProjectDetailComponent},
    { path:'projectEdit/:id', canDeactivate:[ProjectEditGuard], component: ProjectEditComponent},
    ]),
    SharedModule,
    ],
    providers: [ProjectListService,ProjectDetailGuard,ProjectEditGuard],
})
export class ProjectModel{}