import {PipeTransform, Pipe} from '@angular/core';
import {IProjectProperties} from '../Project/projectProperties';

 @Pipe({
 name: "projectFilterPipe"
 })

export class ProjectFilterPipe implements PipeTransform{

transform(value: IProjectProperties[], filterBy:string): IProjectProperties[]{
    filterBy = filterBy? filterBy.toLocaleLowerCase() : null;
     return filterBy? value.filter((project: IProjectProperties)=>
          (project.projectName.toLocaleLowerCase().indexOf(filterBy)!= -1)): value;
 }
}