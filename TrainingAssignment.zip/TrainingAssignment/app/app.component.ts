import { Component } from '@angular/core';
import{ProjectListComponent} from './project/project-list.component'
import {ProjectListService} from './project/project-list.service';

@Component({
    selector: 'pm-app',
    //template: `<h1>Getting starting with Angular2</h1>`    
    template : `<div>
   <nav class='navbar navbar-default'>
   <div class='container-fluid'>
<!-- <a class= 'navbar-brand'>{{pageTitle}}</a>-->
   <ul class = 'nav  navbar-nav'>
   <br/>
   <li><a [routerLink]="['/welcome']"> Home</a></li>
   <li><a [routerLink]="['/projects']"> Project List </a> </li>
   <li><a [routerLink]="['/projectEdit/0']"> Add Project </a> </li>
   <li><a [routerLink]="['/registration']"> Registration </a> </li>
   <li><a [routerLink]="['/help']"> Angular Wiki </a> </li>
   </ul>
   </div>
   </nav>
   <div class = 'container'>
   <router-outlet></router-outlet> 
   </div>
</div>`,
providers:[ProjectListService]
})
export class AppComponent { 
    pageTitle: string = "Project Allocation Portal";
}
