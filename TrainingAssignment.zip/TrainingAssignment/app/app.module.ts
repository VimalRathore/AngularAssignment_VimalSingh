import { NgModule, } from '@angular/core';
import { BrowserModule, } from '@angular/platform-browser';
import {RouterModule,} from '@angular/router';
import {HttpModule} from '@angular/http'
import { ReactiveFormsModule, } from '@angular/forms';

import { AppComponent }  from './app.component';
import {WelcomeComponent} from './home/welcome.component';
import {ProjectListService} from './Project/project-list.service';
import {ProjectDetailGuard, ProjectEditGuard} from './Project/project-gaurd.service'
import {SharedModule} from './shared/shared.module'
import { EmployeeComponent } from './Employee/employee-detail.component';
import {HelpComponent} from './Help/help.component';
import{ProjectModel} from './Project/project.module';
import { LoginComponent } from './login/index';
import { RegisterComponent } from './Register/index';


@NgModule({
  imports: [ BrowserModule,HttpModule,SharedModule,ReactiveFormsModule,ProjectModel,

  RouterModule.forRoot([
    {path:'registration',  component:EmployeeComponent},
    {path:'help',  component:HelpComponent},
    {path:'welcome',  component:WelcomeComponent},
    {path:'', redirectTo:'welcome', pathMatch: 'full'},
    {path:'**', redirectTo:'welcome', pathMatch: 'full'},
    //{ path: 'login', component: LoginComponent },
    //{ path: 'register', component: RegisterComponent },
  ])],
  declarations: [ 
    AppComponent,   
    WelcomeComponent,
    EmployeeComponent,
    HelpComponent,
    LoginComponent,
    RegisterComponent
    ],
    providers: [ProjectListService,ProjectDetailGuard,ProjectEditGuard],
  bootstrap: [ AppComponent ]
})
export class AppModule { 
}
