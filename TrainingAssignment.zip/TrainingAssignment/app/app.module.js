"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var router_1 = require("@angular/router");
var http_1 = require("@angular/http");
var forms_1 = require("@angular/forms");
var app_component_1 = require("./app.component");
var welcome_component_1 = require("./home/welcome.component");
var project_list_service_1 = require("./Project/project-list.service");
var project_gaurd_service_1 = require("./Project/project-gaurd.service");
var shared_module_1 = require("./shared/shared.module");
var employee_detail_component_1 = require("./Employee/employee-detail.component");
var help_component_1 = require("./Help/help.component");
var project_module_1 = require("./Project/project.module");
var index_1 = require("./login/index");
var index_2 = require("./Register/index");
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [platform_browser_1.BrowserModule, http_1.HttpModule, shared_module_1.SharedModule, forms_1.ReactiveFormsModule, project_module_1.ProjectModel,
                router_1.RouterModule.forRoot([
                    { path: 'registration', component: employee_detail_component_1.EmployeeComponent },
                    { path: 'help', component: help_component_1.HelpComponent },
                    { path: 'welcome', component: welcome_component_1.WelcomeComponent },
                    { path: '', redirectTo: 'welcome', pathMatch: 'full' },
                    { path: '**', redirectTo: 'welcome', pathMatch: 'full' },
                ])],
            declarations: [
                app_component_1.AppComponent,
                welcome_component_1.WelcomeComponent,
                employee_detail_component_1.EmployeeComponent,
                help_component_1.HelpComponent,
                index_1.LoginComponent,
                index_2.RegisterComponent
            ],
            providers: [project_list_service_1.ProjectListService, project_gaurd_service_1.ProjectDetailGuard, project_gaurd_service_1.ProjectEditGuard],
            bootstrap: [app_component_1.AppComponent]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map