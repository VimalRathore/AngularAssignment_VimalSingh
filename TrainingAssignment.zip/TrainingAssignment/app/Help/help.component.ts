import {Component} from '@angular/core'

@Component({
    moduleId: module.id,
    templateUrl : 'help.component.html'
})

export class HelpComponent{

}